﻿using HistoricalExchangeRateApi.Helper;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
namespace HistoricalExchangeRateApi.Controllers
{
    public class ExchangeRateController : ApiController
    {


        [HttpGet]
        public string Index()
        {
            return "Welcome";
        }

        [HttpGet]
        public HttpResponseMessage FindHistoricalRate(string startDate, string endDate, string baseCurrency, string targetCurrency)
        {
            List<string> output = new List<string>();
            using (var client = new HttpClient())
            {
                string clientURl = "https://api.exchangeratesapi.io/history?symbols="+targetCurrency+"&start_at="+startDate+"&end_at="+endDate+"&base="+baseCurrency+"";
                client.BaseAddress = new Uri("https://api.exchangeratesapi.io/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //GET Method  
                HttpResponseMessage response1 = client.GetAsync(clientURl).Result;
                if (response1.IsSuccessStatusCode)
                { 
                    var content = response1.Content.ReadAsStringAsync();
                    JObject d = JObject.Parse(content.Result);
                    JsonHelper helper = new JsonHelper();
                    var exchangeRates = helper.ConvertExchangeRate(d);
                    //Min Rate
                    var min = exchangeRates.OrderBy(e => e.ExchangeRate).FirstOrDefault();
                    output.Add("A min rate of " + min.ExchangeRate.ToString() + " on " + min.ExchangeDate.ToString("yyyy-MM-dd"));
                    //Max Rate
                    var max = exchangeRates.OrderByDescending(e => e.ExchangeRate).FirstOrDefault();
                    output.Add("A max rate of " + max.ExchangeRate.ToString() + " on " + max.ExchangeDate.ToString("yyyy-MM-dd"));
                    //Avg Rate 
                    var average = exchangeRates.Average(i => i.ExchangeRate);
                    output.Add("An average rate of " + average.ToString());
                }
                else
                {
                    // Return  Non Success response
                    var content = response1.Content.ReadAsStringAsync();
                    JObject d = JObject.Parse(content.Result);
                    HttpResponseMessage errorResponse = Request.CreateResponse(response1.StatusCode, d);
                    return errorResponse;
                }
            }
            // Return OK response
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, output);
            return response;
        }       
    }
}
