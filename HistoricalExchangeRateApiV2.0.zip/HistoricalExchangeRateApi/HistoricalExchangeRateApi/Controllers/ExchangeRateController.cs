﻿using HistoricalExchangeRateApi.Helper;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Http;
namespace HistoricalExchangeRateApi.Controllers
{
    public class ExchangeRateController : ApiController
    {
      

        [HttpGet]
        public async Task<HttpResponseMessage> FindHistoricalRate(string startDate, string endDate, string baseCurrency, string targetCurrency)
        {
            List<string> expectedOutput = new List<string>();
            using (var client = new HttpClient())
            {
                string clientURl = "https://api.exchangeratesapi.io/history?symbols="+targetCurrency+"&start_at="+startDate+"&end_at="+endDate+"&base="+baseCurrency+"";
                client.BaseAddress = new Uri("https://api.exchangeratesapi.io/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //GET Method  
                HttpResponseMessage clientResponse = await client.GetAsync(clientURl);
                if (clientResponse.IsSuccessStatusCode)
                { 
                    var responseContent = clientResponse.Content.ReadAsStringAsync();
                    JObject jsonResponse = JObject.Parse(responseContent.Result);
                    JsonHelper helper = new JsonHelper();
                    var exchangeRates = helper.ConvertExchangeRate(jsonResponse);
                    //Min Rate
                    var minExchangeRate = exchangeRates.OrderBy(e => e.ExchangeRate).FirstOrDefault();
                    expectedOutput.Add("A min rate of " + minExchangeRate.ExchangeRate.ToString() + " on " + minExchangeRate.ExchangeDate.ToString("yyyy-MM-dd"));
                    //Max Rate
                    var maxExchangeRate = exchangeRates.OrderByDescending(e => e.ExchangeRate).FirstOrDefault();
                    expectedOutput.Add("A max rate of " + maxExchangeRate.ExchangeRate.ToString() + " on " + maxExchangeRate.ExchangeDate.ToString("yyyy-MM-dd"));
                    //Avg Rate 
                    var avgExchangeRate = exchangeRates.Average(i => i.ExchangeRate);
                    expectedOutput.Add("An average rate of " + avgExchangeRate.ToString());
                }
                else
                {
                    // Return  Non Success response
                    var responseContent = clientResponse.Content.ReadAsStringAsync();
                    JObject  jsonError = JObject.Parse(responseContent.Result);
                    HttpResponseMessage errorResponse = Request.CreateResponse(clientResponse.StatusCode, jsonError);
                    return errorResponse;
                }
            }
            // Return OK response
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, expectedOutput);
            return response;
        }       
    }
}
