﻿using HistoricalExchangeRateApi.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Web;

namespace HistoricalExchangeRateApi.Helper
{
    public  class JsonHelper
    {
        public List<Exchange> ConvertExchangeRate (JObject jsonResponse )
        {
            List<Exchange> objExchangeRates = new List<Exchange>();
             foreach (dynamic data in jsonResponse)
                    {
                        if (data.Key == "rates")
                        {
                            var jsonObject = (JObject)data.Value;

                            foreach (JToken token in jsonObject.Children())
                            {
                                Exchange newExchangeRate = new Exchange();
                                if (token is JProperty)
                                {
                                    var property = token as JProperty;
                            newExchangeRate.ExchangeDate = DateTime.ParseExact(property.Name, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                                    var newObj = (JObject)property.Value;
                                            foreach (JToken nextToken in newObj.Children())
                                            {
                                                if (nextToken is JProperty)
                                                {
                                                    var childProperty = nextToken as JProperty;
                                    newExchangeRate.ExchangeRate = decimal.Parse(childProperty.Value.ToString());
                                                }
                                            }
                                }
                        objExchangeRates.Add(newExchangeRate);

                             }
                        }
                    }
            return objExchangeRates;
        }
    }
}